import React from 'react'

function Widgets() {
    return (
        <div className="widgets">
            <iframe src="https://ads.google.com/intl/en_in/getstarted/?subid=in-en-ha-aw-sk-c-m00!o3~Cj0KCQiAyoeCBhCTARIsAOfpKximqICi9P5AXPDkTp3cpcv_iP1sAoIOXztFM-Nko6Sn1gRUhLd2BwwaAk4KEALw_wcB~113746059738~kwd-707754774869~10099607009~476776334852&gclid=Cj0KCQiAyoeCBhCTARIsAOfpKximqICi9P5AXPDkTp3cpcv_iP1sAoIOXztFM-Nko6Sn1gRUhLd2BwwaAk4KEALw_wcB&gclsrc=aw.ds"
                width="340"
                height="100%"
                style={{border:"none", overflow:"hidden"}}
                scrolling="no"
                frameBorder="0"
                allowTransparency="true"
                allow="encrypted">
            </iframe>
        </div>
    )
}

export default Widgets;
